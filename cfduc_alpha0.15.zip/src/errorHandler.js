const errorRegistry = require("./errorRegistry.js");
const jsl = require("svjsl");
const keypress = require('keypress');
const index = require("./index.js");

module.exports = (code, fatal, addInfo) => {
    let errorMessage = errorRegistry[code].message;
    if(jsl.isEmpty(errorMessage)) {
        console.log("\x1b[31m\x1b[1mCouldn't talk to the error registry, please contact me (Sv443) to resolve this issue and provide this info: \x1b[0m\nCode: " + errorMessage + "\nAll:" + JSON.stringify(errorRegistry));
        exitprompt();
    }
    let additionalInfo = "";
    if(!jsl.isEmpty(addInfo)) additionalInfo = "\n\x1b[33mAdditional Info - please include this in an error report: \x1b[0m" + addInfo;

    console.log("\x1b[31m\x1b[1mGot Error " + code + ":\n\x1b[33m" + errorMessage + additionalInfo + "\n\x1b[0m");
    if(fatal) exitprompt();
}

function exitprompt() {
    console.log("\n\n\n" + index.timestamp() + "  \x1b[33m\x1b[1mPress any key to exit...   \x1b[0m");
    keypress(process.stdin);

    process.stdin.on('keypress', function (ch, key) {
        process.exit(1);
    });

    process.stdin.setRawMode(true);
    process.stdin.resume();
}
module.exports.exitprompt = exitprompt;