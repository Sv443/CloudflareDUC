require('dotenv').config();
const https = require("https");
const http = require("http");
const getMyIP = require('get-my-ip');
const jsl = require("svjsl");
const keypress = require("keypress");
const XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
const perf = require('execution-time')();

const developerMode = false;
const version = "v0.2 (alpha)";

const errorHandler = require("./errorHandler.js");
const settings = setting = require("./getSettings.js");

const api_token = process.env.CFDUC_TOKEN;
const ca_key = process.env.CFDUC_CAKEY;
const auth_email = process.env.CFDUC_EMAIL;

var shuttingdown = false;

keypress(process.stdin);
process.stdin.on('keypress', function (ch, key) {
    if (key && key.ctrl && key.name == 'c') {
        shuttingdown = true;
        errorHandler.exitprompt();
    }
});
process.stdin.setRawMode(true);
process.stdin.resume();

if(jsl.isArrayEmpty([api_token, ca_key, auth_email]) !== false) {
    shuttingdown = true;
    errorHandler(600, true, "arr " + jsl.isArrayEmpty([api_token, ca_key, auth_email]));
}

const hostURL = setting.hosturl;
const http_or_https = setting.hostprotocol;

var currentIP;
var needsUpdate = false;
var startupsuccess = 0;
var zone_id = "", dns_identifiers = [], update_urls = [];

process.on('SIGTERM', function(){shuttingdown = true;errorHandler.exitprompt();});
process.on('SIGINT', function(){shuttingdown = true;errorHandler.exitprompt();});

console.log("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCloudflareDUC " + version + "\n\x1b[32mStarting application...\x1b[0m");
console.log("Don't worry if you get a 4xx status, only 5xx statuses will require a DNS update.\n");

if(!developerMode) {
    getOwnIP();
    setInterval(()=>getOwnIP, 5000);

    function getOwnIP() {
        if(!shuttingdown) {
            currentIP = getMyIP();
            currentIP = "2.205.169.210";                         // ----------------------------------------------------------------------------------------------------------------
            if(jsl.isEmpty(currentIP)) {
                shuttingdown=true;
                errorHandler(100, true, "received IP " + currentIP + " /typeof " + typeof currentIP);
            }
        }
    }
}
else {
    console.log("\x1b[33m\x1b[1m[!] \x1b[0mDeveloper Mode is enabled! \x1b[33m\x1b[1m[!]\x1b[0m\n");
    currentIP = "123.456.78.90";
}






perf.start();

initializeAll();






function initializeAll() {
    progress(1);
    setInterval(()=>{
        if(!shuttingdown) {
            //jsl.consoleColor("\nStSc: " + startupsuccess, "bright fgblue");
            if(startupsuccess == 0) init.getID();
            else if(startupsuccess == 1) init.getDNS();
            else if(startupsuccess == 2) init.pingInterval();
            else if(startupsuccess == 3) {
                progress(7);
                // let startupDuration = performance.getEntriesByName('startupDuration')[0].duration * 1000;
                var startupDuration = Math.floor(perf.stop().time / 1000);

                console.log("\x1b[32m\x1b[1mStartup finished in " + startupDuration + " seconds\x1b[0m");
                startupsuccess = 4;
                setTimeout(()=>{updateRecord();},3000);  /* TESTING        TESTING        TESTING        TESTING        TESTING        TESTING        TESTING        TESTING        TESTING */
            }
            else if(startupsuccess == 4) {}
            else if(startupsuccess == "err") {
                errorHandler("101", true, "StSc_code: " + startupsuccess + " /typeof " + typeof startupsuccess);
                shuttingdown = true;
            }
            else {
                errorHandler("101", true, "StSc_code: " + startupsuccess + " /typeof " + typeof startupsuccess);
                shuttingdown = true;
            }
        }
    }, settings.timeout * 350);
}

function updateRecord() {
    if(shuttingdown) return;
    if(startupsuccess == 2) startupsuccess = 3;
    console.log("\n\n\x1b[1m\x1b[33m[UPDATE]        \x1b[31mupdating DNS record with API token \x1b[33m[HIDDEN]" + api_token.substring(api_token.length-10) + "\x1b[31m\n                and CA key \x1b[33mv1.0-[HIDDEN]" + ca_key.substring(ca_key.length-10) + " \x1b[31m\n                and email \x1b[33m" + auth_email + "\x1b[31m\n\n                to IP \x1b[34m" + currentIP + "\x1b[0m\n");

    var xhrs = [];

    for(let i = 0; i < update_urls.length; i++) {
        var requrl = `https://api.cloudflare.com/client/v4/zones/${zone_id}/dns_records/${update_urls[i].id}/`;

        var writtenData = JSON.stringify({
            "type": update_urls[i].type,
            "name": update_urls[i].name,
            "content": currentIP,
            "proxied": update_urls[i].proxied
        });

        // console.log("DATA " + writtenData);

        xhrs[i] = new XMLHttpRequest();
        xhrs[i].open("PUT", requrl, true);
        xhrs[i].setRequestHeader("X-AUTH-KEY", api_token);
        xhrs[i].setRequestHeader("X-AUTH-USER-SERVICE-KEY", ca_key);
        xhrs[i].setRequestHeader("X-AUTH-EMAIL", auth_email);
        xhrs[i].setRequestHeader("Content-Type", "application/json");
        xhrs[i].addEventListener('load', function(e) {
            let reqWasSuccessful = false;
            try {
                reqWasSuccessful = JSON.parse(xhrs[i].responseText).success;
            }
            catch(err) {
                errorHandler(202, false, "Caught error: " + err);
            }

            if ((xhrs[i].status >= 200 && xhrs[i].status < 300) || xhrs[i].status == 0) {
                if(reqWasSuccessful) console.log("\n\x1b[1m\x1b[33m[UPDATED]\x1b[0m        Successfully updated \"" + update_urls[i].type + "\"-record with name \"" + update_urls[i].name + "\"");
            }
            else {
                if(xhrs[i].responseText == "null" || jsl.isEmpty(xhrs[i].responseText)) console.log("\n\x1b[1m\x1b[33m[UPDATED]\x1b[0m        ERROR: " + xhr.statusText + " -- " + xhr.responseText);
            }
        });
        xhrs[i].send(writtenData);
    }
}

const init = {
    getID: () => {
        progress(2);
        let uHOST = "api.cloudflare.com";
        let uPATH = "/client/v4/zones";
        let data = "";
        if(!shuttingdown) {
            https.get({
                headers: {
                    "X-AUTH-KEY": api_token,
                    "X-AUTH-USER-SERVICE-KEY": ca_key,
                    "X-AUTH-EMAIL": auth_email
                },
                hostname: uHOST,
                path: uPATH,
                timeout: settings.timeout
            }, (res) => { 
                // console.log('statusCode: ', res.statusCode);
                
                res.on('data', (d) => {
                    data += d;
                });
            }).on('error', (e) => {
                errorHandler("200", true, "init.getID got error " + e);
                shuttingdown = true;
                startupsuccess = "err";
            }).on('close', ()=> {
                try {
                    if(JSON.parse(data).success == true) {
                        zone_id = JSON.parse(data).result[0].id;
                    }
                    else throw new Error("\n" + data);
                }
                catch(err) {
                    errorHandler(601, true, "Caught error: " + err);
                    shuttingdown = true;
                }
                progress(3);
                // console.log("Zone ID: " + zone_id);
                startupsuccess = 1;
            });
        }
    },
    getDNS: () => {
        progress(4);
        let uHOST = "api.cloudflare.com";
        let uPATH = "/client/v4/zones/" + zone_id + "/dns_records/";
        let data = "";
        if(!shuttingdown) {
            https.get({
                headers: {
                    "X-AUTH-KEY": api_token,
                    "X-AUTH-USER-SERVICE-KEY": ca_key,
                    "X-AUTH-EMAIL": auth_email
                },
                hostname: uHOST,
                path: uPATH,
                timeout: settings.timeout
            }, (res) => { 
                // console.log('statusCode: ', res.statusCode);
                res.on('data', (d) => {
                    data += d;
                });
            }).on('error', (e) => {
                errorHandler("201", true, "init.getDNS got error " + e);
                shuttingdown = true;
                startupsuccess = "err";
            }).on('close', ()=> {
                try {
                    if(JSON.parse(data).success == true) {
                        dns_identifiers = JSON.parse(data).result;
                        // console.log("DNS ID: " + dns_identifiers);
                        progress(5);
                        for(let i = 0; i < dns_identifiers.length; i++) {
                            startupsuccess = 2;
                            update_urls.push(dns_identifiers[i]);
                        }
                    }
                    else throw new Error("\n" + data);
                }
                catch(err) {
                    errorHandler(601, true, "Caught error: " + err);
                    shuttingdown = true;
                }
            });
        }
    },
    pingInterval: () => {
        try {
            progress(6);
            startupsuccess = 3;
            if(!shuttingdown) pingHost();
            setTimeout(()=>{
                if(needsUpdate) updateRecord();
            }, settings.timeout * 1000 + 500);
            setInterval(()=>{
                if(startupsuccess == 4) {
                    if(!shuttingdown) pingHost();
                    setTimeout(()=>{
                        if(needsUpdate) updateRecord();
                    }, settings.timeout * 1000 + 500);
                }
            }, settings.interval * 1000);
        }
        catch(err) {
            errorHandler(300, true, "caught error: " + err);
        }
    }
}

function pingHost() {
    var req, statuscode = "ERR";
    try {
        let url = settings.hosturl, httpver;
        if(url.split("://")[0] == "https") httpver = "https";
        else httpver = "http";

        if(httpver == "https" && !shuttingdown) req = https.get(url, function(res){statuscode = res.statusCode;});
        else if(httpver == "http" && !shuttingdown) req = http.get(url, function(res){statuscode = res.statusCode;});

        setTimeout(function() {
            try {
                let currentDate = timestamp();
                statuscode = parseInt(statuscode);
                if(!shuttingdown && statuscode < 500) process.stdout.write("\n\x1b[1m\x1b[33m@" + statuscode + "\x1b[0m - ");
                else if(!shuttingdown && statuscode >= 500) process.stdout.write("\n\x1b[1m\x1b[31m@" + statuscode + "\x1b[0m - ");
                if((!shuttingdown && statuscode >= 500 && statuscode < 600) || (!shuttingdown && isNaN(statuscode))) {needsUpdate = true;process.stdout.write("updating...");}
                else if(!shuttingdown && (statuscode == undefined || statuscode == null)) sendErrorMsg("couldn't get a response from your server. Make sure it is running and publicly accessible!");
                else if(!shuttingdown && statuscode == 200) {process.stdout.write("ok (own IP: \x1b[2m\x1b[33m" + currentIP + "\x1b[0m)  -  " + currentDate);needsUpdate = false;}
                else if(!shuttingdown && statuscode != 200 && statuscode < 500) {process.stdout.write("ok (but not 200) (own IP: \x1b[2m\x1b[33m" + currentIP + "\x1b[0m)  -  " + currentDate);needsUpdate = false;}
                else {}
                process.stdout.write("\n\x1b[0m");
            }
            catch(err) {
                errorHandler(301, false, "Caught error: " + err);
            }
        }, setting.timeout * 1000);
    }
    catch(err) {
        errorHandler(301, false, "Caught error: " + err);
    }
}

function progress(current) {
    if(!shuttingdown) {
        let maximum = 7;
        current = Math.floor(current * (100 / maximum));
        if(current == 100) {
            process.stdout.clearLine();
            process.stdout.cursorTo(0);
            process.stdout.write("\n");
            return;
        }
        process.stdout.clearLine();
        process.stdout.write("> \x1b[32m\x1b[1mStarting up:\x1b[0m \x1b[33m\x1b[1m" + current + "%\x1b[0m complete");
        process.stdout.cursorTo(0);
    }
}





function sendErrorMsg(msg) {
    console.log("\x1b[1m\x1b[31m[ERROR] \x1b[0m" + msg);
}

function timestamp() {
    let d = new Date(), hp = "", mp = "", sp = "", mop = "", dp = "";
    if(d.getHours() < 10) hp = "0";
    if(d.getMinutes() < 10) mp = "0";
    if(d.getSeconds() < 10) sp = "0";
    if(d.getMonth() < 10) mop = "0";
    if(d.getDate() < 10) dp = "0";
    return "[" + hp + d.getHours() + ":" + mp + d.getMinutes() + ":" + sp + d.getSeconds() + " - " + d.getFullYear() + "." + mop + d.getMonth() + "." + dp + d.getDate() + "]";
}
module.exports.timestamp = timestamp;